<?php
return [
    'author' => 'O:28:"vova07\\rbac\\rules\\AuthorRule":3:{s:4:"name";s:5:"autor";s:9:"createdAt";N;s:9:"updatedAt";N;}',
];
