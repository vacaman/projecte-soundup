<?php
return [
    1 => [
        'superadmin',
    ],
];
