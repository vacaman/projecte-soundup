<?php

namespace vova07\rbac;

use Yii;

/**
 * Module [[RBAC]]
 * Yii2 RBAC module.
 */
class Module extends \vova07\base\components\Module
{
    /**
     * @inheritdoc
     */
    public static $name = 'rbac';
}
