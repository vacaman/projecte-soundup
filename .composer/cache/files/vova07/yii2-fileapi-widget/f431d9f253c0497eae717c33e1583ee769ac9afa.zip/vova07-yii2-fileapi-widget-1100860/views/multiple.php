<?php

/**
 * Multiple upload view.
 *
 * @var \yii\web\View $this View
 */

?>