<?php

namespace vova07\comments;

use Yii;

/**
 * Comments module.
 */
class Module extends \vova07\base\components\Module
{
    /**
     * @inheritdoc
     */
    public static $name = 'comments';
}
