<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=127.0.0.1;dbname=yii2-start',
    'username' => 'root',
    'password' => '12345',
    'charset' => 'utf8',
    'tablePrefix' => 'yii2_start_'
];
