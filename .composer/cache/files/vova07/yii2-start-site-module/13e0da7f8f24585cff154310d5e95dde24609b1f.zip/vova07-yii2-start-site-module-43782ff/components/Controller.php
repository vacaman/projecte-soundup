<?php

namespace vova07\site\components;

/**
 * Main frontend controller.
 */
class Controller extends \yii\web\Controller
{
}
