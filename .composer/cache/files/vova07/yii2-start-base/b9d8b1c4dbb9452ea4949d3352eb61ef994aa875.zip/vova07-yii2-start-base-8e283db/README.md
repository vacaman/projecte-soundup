Yii2-Start base.
================
This is the base extension of Yii2-Start application.

Installation
------------

The preferred way to install this extension is through [composer](http://getcomposer.org/download/).

Either run

```
php composer.phar require --prefer-dist vova07/yii2-start-base "*"
```

or add

```
"vova07/yii2-start-base": "*"
```

to the require section of your `composer.json` file.